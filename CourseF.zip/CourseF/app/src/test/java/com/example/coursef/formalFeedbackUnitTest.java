package com.example.coursef;

import org.junit.Test;

import static org.junit.Assert.*;

public class formalFeedbackUnitTest {
    @Test
    public void cred_True() {

    }
}